﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Teste_Tecnico_Tapps
{
    class ImpulsivePlayer : Player
    {
    }
}
